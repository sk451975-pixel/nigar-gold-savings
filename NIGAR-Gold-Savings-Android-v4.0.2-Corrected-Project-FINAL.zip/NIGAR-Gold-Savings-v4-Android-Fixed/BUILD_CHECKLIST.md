# NIGAR v4.0.2 build checklist

1. Open the project in Android Studio.
2. Confirm `app/src/main/assets/config.js` contains the intended Supabase URL and publishable/anon key.
3. Sync Gradle.
4. Build and install the debug APK.
5. Open the app while internet is enabled.
6. Test login. A wrong password should show a Supabase authentication message; network failure should show a network/connection message.
7. After login, test Customers → Payments → Receipt/PDF → Passbook.
8. If login succeeds but database reads fail, check Supabase RLS/policies rather than changing the Android network code.
