# NIGAR Gold Savings Android v4.0.2 — corrected Android project

This project packages the existing NIGAR Gems & Jewellers v4 web application inside a native Android WebView.

## Important fix
The app is **not** loaded from `file://`. `MainActivity` uses AndroidX `WebViewAssetLoader` and loads:

`https://appassets.androidplatform.net/assets/index.html`

This gives the local web app a secure HTTPS origin and avoids the fragile `file://` origin when it communicates with Supabase.

## Included
- Existing NIGAR v4 application UI and business features
- Existing Supabase configuration file (`config.js`)
- Existing NIGAR logo and PWA assets
- Secure WebViewAssetLoader origin
- Android INTERNET permission
- JavaScript, DOM storage and database storage enabled
- Clear login/network error messages instead of only “Failed to fetch”
- Android back navigation
- GitHub Actions workflow to build a debug APK
- Version 4.0.2 / versionCode 3

## Supabase security
The APK uses the configured **publishable/anon key**. Do not replace it with a Supabase secret or service-role key. Database access must remain protected by Supabase Row Level Security (RLS).

## Build

### Android Studio
1. Open this folder in Android Studio.
2. Allow Gradle sync to finish.
3. Run the `app` configuration on an Android device/emulator.
4. For a test APK use **Build → Build APK(s)**.

### GitHub Actions
Push the project to GitHub. The included workflow builds `app-debug.apk` and uploads it as an Actions artifact. You can also run the workflow manually from **Actions → Build NIGAR Gold Savings APK → Run workflow**.

## Notes
The web app still needs internet access for Supabase authentication/database operations and for its CDN-hosted JavaScript libraries (Supabase JS and jsPDF).
