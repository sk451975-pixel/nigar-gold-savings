// Nigar Gems & Jewellers — connected Supabase configuration.
// The publishable/anon key is safe for browser use when protected by Supabase RLS.
// NEVER put a service_role/secret key in this file.
window.NIGAR_CONFIG = {
  supabaseUrl: 'https://ewzmnbtghhuylksresut.supabase.co',
  supabaseAnonKey: 'sb_publishable_29qh7wJSsQECA6YTAFIxSg_yTO1jvFN'
};
